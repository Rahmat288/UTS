package com.example.riksan.uts;

import android.content.Context;
import android.support.annotation.LayoutRes;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

/**
 * Created by riksan on 20/11/17.
 */

public class c_listview extends ArrayAdapter{

    private final Context context;
    private final String[] values;
    private int[] gambar;

    public c_listview(Context context, String[] values) {
        super(context, R.layout.c_listview,values);
        this.context = context;
        this.values = values;
        //this.gambar = gambar;
    }

    public void setGambar(int[] gambar){
        this.gambar =gambar;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        LayoutInflater inflater = (LayoutInflater) context
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        View rowView = inflater.inflate(R.layout.c_listview, parent, false);
        TextView tv = (TextView) rowView.findViewById(R.id.label);
        ImageView iv = (ImageView) rowView.findViewById(R.id.logo);

        switch (position){
            case 0 :
                iv.setImageResource(gambar[0]);
                tv.setText(values[0]);
                break;
            case 1 :
                iv.setImageResource(gambar[1]);
                tv.setText(values[1]);
                break;
            case 2 :
                iv.setImageResource(gambar[2]);
                tv.setText(values[2]);
                break;
            default: break;
        }
        return rowView;
    }
}
