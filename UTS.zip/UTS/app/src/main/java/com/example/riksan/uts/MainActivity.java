package com.example.riksan.uts;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

public class MainActivity extends AppCompatActivity {

    String[] Values={"Contoh","aaaa","bbbb"};
    int[] gambar={R.drawable.ex,R.drawable.ex,R.drawable.ex};
    ListView list1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        c_listview adapter= new c_listview(this,Values);
        adapter.setGambar(gambar);
        list1 = (ListView) findViewById(R.id.list1);
        list1.setAdapter(adapter);
       // list1.setOnItemClickListener(this);
    }
}
